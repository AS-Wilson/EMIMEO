
E_0x=1.0   % magnitude of the x component
E_0y=1.0   % magnitude of the y component
z=0;   %
delta=-pi/2       % phase difference
omega=2*pi*0.2e9; % angular frequency
k=omega/3e8;      % wavevector
deltat=0.08e-9;   % time increment
deltaz=0.02;      % space increment    
z=[0:deltaz:200*deltaz];

figure

disp('Strike any key to start!')
pause  % strike any key to start

view([4 4 4])
hold on
axis equal
axis([0 4 -1.05 1.05 -1.05 1.05])
plot3([0 4],[0 0],[0 0],'r','linewidth',2)  % plot z-axis
%arrow3([0 0 0],[4 0 0],'r-2')  % plot z-axis
grid on
set(gca,'fontsize',16)
ylabel('\fontname{Script MT Bold}E_{\fontname{Arial}x}') % if it doesn't work use ylabel('E_x')
zlabel('\fontname{Script MT Bold}E_{\fontname{Arial}y}') % if it doesn't work use zlabel('E_y')
%ylabel('E_x')
%zlabel('E_y')
xlabel('z')  
    
  
time_step_max=200; % number of time steps
for time_step=0:time_step_max
 
  E_x=E_0x*cos(omega*time_step*deltat-k*z);
  E_y=E_0y*cos(omega*time_step*deltat-k*z+delta);
  curve=plot3(z,E_x,E_y,'-','linewidth',2,'color','b');
  E_x_old=E_x;
  E_y_old=E_y;
  
  % it draws arrows
  global ColorOrder, ColorOrder=[];
  set(gca,'ColorOrder',[0,1,0])
  field_vector=[];
  for mm=1:1:floor(length(z)/10)
    %field_vector(mm)=plot3([z(mm*10) z(mm*10)],[0 x(mm*10)],[0 y(mm*10)],'g','linewidth',2) ;
    field_vector(mm,:)=arrow3([z(mm*10) 0 0],[z(mm*10) E_x(mm*10) E_y(mm*10)],'g2') ;
  end
  
  pause(0.05) % it controls the speed of the rotating arrow
  
  if time_step<time_step_max
   delete(field_vector)
   delete(curve)
  end
  
end

