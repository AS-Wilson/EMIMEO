
E_0x=1.0 % amplitude of the x component
E_0y=1.0 % amplitude of the y component
z=0; %  
delta=-pi/2      % phase difference
omega=2*pi*1e9;  % angular frequency 
k=omega/3e8;     % wavevector 
deltat=0.01e-9;  % time increment

figure

disp('Strike any key to start!')
pause   % strike any key to start


plot([-1.05 1.05],[0 0],'k')  % plot x-axis
hold on
plot([0 0],[-1.05 1.05],'k')  % plot y-axis
axis equal
axis([-1.05 1.05 -1.05 1.05])
set(gca,'fontsize',16)
xlabel('\fontname{Script MT Bold}E_{\fontname{Arial}x}') % if it doesn't work use xlabel('E_x')
ylabel('\fontname{Script MT Bold}E_{\fontname{Arial}y}') % if it doesn't work use ylabel('E_y')
%xlabel('E_x')
%ylabel('E_y')

time_step_max=200; % number of time steps  
for time_step=0:time_step_max
 
  E_x=E_0x*cos(omega*time_step*deltat-k*z);
  E_y=E_0y*cos(omega*time_step*deltat-k*z+delta);
  %plot(x,y,'o','color','b')
  if time_step~=0
  plot([E_x_old E_x],[E_y_old E_y],'linewidth',2,'color','b')
  end
  
  E_x_old=E_x;
  E_y_old=E_y;
  
  %field_vector=plot([0 E_x],[0 E_y],'g','linewidth',2) ;
  
  % it draws an arrow
  global ColorOrder, ColorOrder=[];
  set(gca,'ColorOrder',[0,1,0])
  field_vector=arrow3([0 0],[E_x E_y],'g-2') ; % field vector
  %
  
  pause(0.05) % it controls the speed of the rotating arrow
   
  if time_step<time_step_max
   delete(field_vector)
  end
  
end

