
theta=linspace(0,360,3601)*pi/180;
rho=sin(theta).^2;    % short dipole
rho_dB=10*log10(abs(rho)); % logarithmic scale

h=mmpolar(theta,rho_dB, 'r', 'RLimit', [-20 0], 'RTickValue', [-20:5:0], 'TTickDelta', 30, ...
  'TZeroDirection', 'North', 'TDirection', 'cw',...
  'RTickLabelVisible', 'on', 'TTickLabelVisible', 'on', 'RTickVisible', 'off',...
  'RGridLineWidth', 1, 'TGridLineWidth', 1, 'fontsize', 14, 'TTickOffset', 0.16);
set(h, 'LineWidth', 3);
