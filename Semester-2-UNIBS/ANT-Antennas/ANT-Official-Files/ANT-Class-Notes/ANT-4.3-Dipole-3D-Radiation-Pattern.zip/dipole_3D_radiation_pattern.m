%
% 3D radiation pattern of a short dipole
%

theta=linspace(0,pi,100);
phi=linspace(0,2*pi,100);

[theta_m,phi_m]=meshgrid(theta,phi);

r=sin(theta_m).^2;

x=r.*sin(theta_m).*cos(phi_m);
y=r.*sin(theta_m).*sin(phi_m);
z=r.*cos(theta_m);

% figure
% surf(x,y,z)
% xlabel('x')
% ylabel('y')
% zlabel('z')
% axis equal
% view([1,1,1])

figure
% color "proportional" to the distance from the origin
surf(x,y,z,sqrt(x.^2+y.^2+z.^2),'edgecolor','none','facecolor','interp') 
%surf(x,y,z,sqrt(x.^2+y.^2+z.^2))
%colormap jet
colormap(flipud(hot))
caxis([0 1.0])
colorbar
xlabel('x')
ylabel('y')
zlabel('z')
axis equal
view([1,1,1])
