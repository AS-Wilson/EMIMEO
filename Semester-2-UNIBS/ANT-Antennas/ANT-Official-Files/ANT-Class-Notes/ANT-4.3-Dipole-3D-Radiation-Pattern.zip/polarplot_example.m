
theta=[0.0:1:360]*pi/180;
rho=abs(sin(theta).^2);    % short dipole
rho_dB=10*log10(rho);      % logarithmic scale
% rmax=1;    % upper limit of the r-axis 
% rstep=0.2; % separation between ticks  
% rmin=0;    % lower limit of the r-axis 
rmax=0;   % upper limit of the r-axis (dB scale)
rstep=5;  % separation between ticks (dB scale) 
rmin=-20; % lower limit of the r-axis (dB scale)
for k=1:length(rho_dB)   % it change values smaller than rmin  
    if rho_dB(k)<rmin
       rho_dB(k)=rmin;
    end
end    
        
polarplot(theta,rho_dB,'linewidth',2,'color','g')
rlim([rmin rmax])     % change the limits of the r-axis
rticks=[rmin:rstep:rmax]; % radius tick valuesrticklabels([]);
rticklabels([]);
thetaticklabels([]);
pax=gca;          % handle to current axise
pax.ThetaDir='clockwise'; % direction of increasing angle ('counterclockwise' or 'clockwise')
pax.ThetaZeroLocation='top'; % location of the zero reference axis ('right','top','left','bottom')
pax.FontSize=12;  % fontsize

% draw new polar axes to superimpose the tick values on polar line
ax1=gca;
ax2 = polaraxes('Position',ax1.Position,'color','none');
rlim([rmin rmax])    
rticks=[rmin:rstep:rmax];
%rticklabels([]);
%thetaticklabels([]);
ax2.ThetaDir='clockwise'; 
ax2.ThetaZeroLocation='top'; 
ax2.FontSize=12; 
