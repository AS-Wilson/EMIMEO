function out = do_fs(in)
   out = ((0:1:(length(in)-1))/(0.5*length(in))-1)/2;
end
