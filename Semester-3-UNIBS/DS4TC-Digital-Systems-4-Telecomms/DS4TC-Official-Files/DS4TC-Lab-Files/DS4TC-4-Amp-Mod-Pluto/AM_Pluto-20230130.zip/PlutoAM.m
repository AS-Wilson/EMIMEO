%clear('all');

% COMMON PARAMETERS
bb_rate = 48e3;
tx_rate = 240e3;
rx_rate = 240e3;
fc = 2.45e9;                     % tuner centre frequency in Hz
fc_rx = fc-40e3;
sim_time  = 2;                         % simulation time in seconds
samples_per_frame = sim_time*tx_rate;
samples_per_frame_sine = sim_time*bb_rate;

%--------------------------------%
% Transmitter

% Set up modulated waveform
sw1 = dsp.SineWave;
sw1.Amplitude = 1;
sw1.Frequency = 3e3;
sw1.ComplexOutput = false;
sw1.SampleRate = bb_rate;
sw1.SamplesPerFrame = samples_per_frame_sine; % to meet waveform size requirements

sw2 = dsp.SineWave;
sw2.Amplitude = 1;
sw2.Frequency = 1e3;
sw2.ComplexOutput = false;
sw2.SampleRate = bb_rate;
sw2.SamplesPerFrame = samples_per_frame_sine; % to meet waveform size requirements

scale=5; offset = 0.5;
sine1 = sw1()/scale;
sine2 = sw2()/scale;
sine = sine1+sine2+offset;

tx_wave = complex(sine,zeros(size(sine)));

% Rate conversion 48kHz -> 240kHz



% Resample tx_wave


%--------------------------------%
% Receiver
% fir decimator




% fir bandpass filter





% time display object
obj_ts = dsp.TimeScope('SampleRate', bb_rate, 'BufferLength', sim_time*bb_rate, 'TimeSpan', sim_time);

% spectrum analyzers
obj_spectrummod   = dsp.SpectrumAnalyzer(...
    'Name', 'Spectrum Analyzer Modulated',...
    'Title', 'Spectrum Analyzer Modulated',...
    'SpectrumType', 'Power',...
    'FrequencySpan', 'Full',...
    'ShowLegend', true,...
    'SampleRate', rx_rate);

obj_spectrumdemod = dsp.SpectrumAnalyzer(...
    'Name', 'Spectrum Analyzer Demodulated',...
    'Title', 'Spectrum Analyzer Demodulated',...
    'SpectrumType', 'Power',...
    'FrequencySpan', 'Full',...
    'SampleRate', bb_rate); %,...'ViewType', 'Spectrogram');

%SDR objects





% SIMULATION  

% reset run_time to 0 (secs)
run_time = 0;

% loop while run_time is less than sim_time
while run_time < sim_time
    run_time
    

    
    % update run_time after processing another frame
    run_time = run_time + (samples_per_frame/rx_rate);
    
end
