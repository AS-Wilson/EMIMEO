% pluto-SDR(rx) AM Mono Non Coherent Demodulator MATLAB Script
% - This script can be used to non-coherently demodulate an AM-TC signal. 
% - NOTE: to end simulation early, use |Ctrl| + |C|

close('all'); clear('all');

%% COMMON PARAMETERS
bb_rate = 48e3;
tx_rate = 240e3;
rx_rate = 240e3;
fc = 2.45e9;              % tuner centre frequency in Hz
fc_rx = fc-40e3;
sim_time  = 2;                   % simulation time in seconds
samples_per_frame = 24e3*5;      % output data frame size (multiple of 5)
samples_per_frame_sine = samples_per_frame/5;

%% -------------------------------- %%
% Transmitter

% Set up modulated waveform
sw1 = dsp.SineWave;
sw1.Amplitude = 1;
sw1.Frequency = 3e3;
sw1.ComplexOutput = false;
sw1.SampleRate = bb_rate;
sw1.SamplesPerFrame = samples_per_frame_sine; % to meet waveform size requirements

sw2 = dsp.SineWave;
sw2.Amplitude = 1;
sw2.Frequency = 1e3;
sw2.ComplexOutput = false;
sw2.SampleRate = bb_rate;
sw2.SamplesPerFrame = samples_per_frame_sine; % to meet waveform size requirements

scale=5; offset = 0.5;
sine1 = sw1()/scale;
sine2 = sw2()/scale;
sine = sine1+sine2+offset;

tx_wave = complex(sine,zeros(size(sine)));

% Rate conversion 48kHz -> 240kHz
Filter_TX = dsp.FIRInterpolator('InterpolationFactor', 5,...
      'Numerator', firpm(100, [0 15e3 20e3 (240e3/2)]/(240e3/2), [1 1 0 0], [1 1], 20) );  

% Resample tx_wave
tx_wave_resampled = Filter_TX(tx_wave./max(tx_wave));

%% -------------------------------- %%
% Receiver
% fir decimator
obj_decmtr = dsp.FIRDecimator(...
    'DecimationFactor', 5,...
    'Numerator', firpm(100, [0 15e3 20e3 (240e3/2)]/(240e3/2), [1 1 0 0], [1 1], 20));

% fir bandpass filter
obj_bpf = dsp.FIRFilter(...
    'Numerator', firpm(50,[0,20e3,25e3,55e3,60e3,240e3/2]/(240e3/2),...
    [0 0 1 1 0 0],[1 1 1],20));

% time display object
obj_ts = dsp.TimeScope('SampleRate', bb_rate, 'BufferLength', sim_time*bb_rate,...
    'TimeSpan', sim_time+50e-3);

% spectrum analyzers
obj_spectrummod   = dsp.SpectrumAnalyzer(...
    'Name', 'Spectrum Analyzer Modulated',...
    'Title', 'Spectrum Analyzer Modulated',...
    'SpectrumType', 'Power',...
    'FrequencySpan', 'Full',...
    'ShowLegend', true,...
    'SampleRate', rx_rate);

obj_spectrumdemod = dsp.SpectrumAnalyzer(...
    'Name', 'Spectrum Analyzer Demodulated',...
    'Title', 'Spectrum Analyzer Demodulated',...
    'SpectrumType', 'Power',...
    'FrequencySpan', 'Full',...
    'SampleRate', bb_rate); %,...'ViewType', 'Spectrogram');

%% -------------------------------- %%
%SDR objects
obj_tx = sdrtx('Pluto', 'CenterFrequency', fc, 'BasebandSampleRate', tx_rate, 'Gain',-20);
obj_rx = sdrrx('Pluto', 'CenterFrequency', fc_rx, 'BasebandSampleRate', rx_rate,...
    'GainSource', 'Manual', 'Gain',40, 'SamplesPerFrame', samples_per_frame, 'OutputDataType', 'single');


%% -------------------------------- %%
% SIMULATION  

% TX
%continously transmit
obj_tx.transmitRepeat(tx_wave_resampled);

% reset run_time to 0 (secs)
run_time = 0;

% loop while run_time is less than sim_time
while run_time < sim_time
    run_time
    
    % RX
    data = obj_rx();
    
    % bandpass filter data to isolate AM-DSB-TC signal around 40kHz
    data_bpf = obj_bpf(data);
    
    % update 'modulated' spectrum analyzer window with the new frame
    % of data, and the frame of bandpass filtered data
    obj_spectrummod([data,data_bpf]);
    
    % implement complex envelope detector
    env_mag = abs(data_bpf);
    data_dec = obj_decmtr(env_mag);
    
    % update 'demodulated' spectrum analyzer window with new frame
    obj_spectrumdemod(data_dec);
      
    % plot demod data
    obj_ts(data_dec);
    
    % update run_time after processing another frame
    run_time = run_time + (samples_per_frame/rx_rate);
    
end

release(obj_tx); release(obj_rx);
release(obj_spectrumdemod); release(obj_ts); release(obj_spectrummod);