% pluto-SDR(rx) FM Mono Non Coherent Discriminator Demodulator MATLAB Script
% - This script can be used to non-coherently demodulate an FM signal. 
% - NOTE: to end simulation early, use |Ctrl| + |C|

close('all'); clear('all');

%% PARAMETERS
plutosdr_fc        = 868e6;                     % SDR centre frequency in Hz
plutosdr_gain      = 30;                        % SDR gain in dB
plutosdr_fs        = 240e3;                     % SDR sampling rate
plutosdr_frmlen    = 12e3*5;                    % output data frame size (multiple of 5)
plutosdr_datatype  = 'single';                  % output data type
audio_fs         = 48e3;                        % audio output sampling rate
sim_time         = 2;                           % simulation time in seconds
sensitivity		 = 5;


plutosdr_frmtime = plutosdr_frmlen/plutosdr_fs; % calculate time for 1 frame of data


%% SYSTEM OBJECTS


% Set up modulated waveform
scale=5;

sw1 = dsp.SineWave;
sw1.Amplitude = 1/scale;
sw1.Frequency = 3e3;
sw1.ComplexOutput = false;
sw1.SampleRate = audio_fs;
sw1.SamplesPerFrame = plutosdr_frmlen/5; % to meet waveform size requirements

sw2 = dsp.SineWave;
sw2.Amplitude = 1/scale;
sw2.Frequency = 1e3;
sw2.ComplexOutput = false;
sw2.SampleRate = audio_fs;
sw2.SamplesPerFrame = plutosdr_frmlen/5; % to meet waveform size requirements

sine = sw1()+sw2();


% link to a physical pluto-sdr
obj_plutorx = sdrrx(...
    'Pluto',...
    'CenterFrequency', plutosdr_fc,...
    'GainSource', 'Manual',...
    'Gain', plutosdr_gain,...
    'BasebandSampleRate', plutosdr_fs, ...
    'SamplesPerFrame', plutosdr_frmlen,...
    'OutputDataType', plutosdr_datatype);

obj_plutotx = sdrtx(...
    'Pluto',...
    'CenterFrequency', plutosdr_fc,...
    'BasebandSampleRate', plutosdr_fs,...
    'Gain',-20);

% Rate conversion 48kHz -> 240kHz
obj_interp = dsp.FIRInterpolator('InterpolationFactor', 5,...
'Numerator', firpm(100, [0 15e3 20e3 (240e3/2)]/(240e3/2), [1 1 0 0], [1 1], 20) );  

% fir decimator - fs = 240kHz downto 48kHz
obj_decmtr = dsp.FIRDecimator(...
    'DecimationFactor', 5,...
    'Numerator', firpm(100,[0,15e3,20e3,(240e3/2)]/(240e3/2),...
    [1 1 0 0], [1 1], 20));


% spectrum analyzers
obj_spectrummod   = dsp.SpectrumAnalyzer(...
    'Name', 'Spectrum Analyzer Modulated',...
    'Title', 'Spectrum Analyzer Modulated',...
    'SpectrumType', 'Power density',...
    'FrequencySpan', 'Full',...
    'SampleRate', plutosdr_fs);
obj_spectrumdemod = dsp.SpectrumAnalyzer(...
    'Name', 'Spectrum Analyzer Demodulated',...
    'Title', 'Spectrum Analyzer Demodulated',...
    'SpectrumType', 'Power density',...
    'FrequencySpan', 'Full',...
    'SampleRate', audio_fs);

% time display object
obj_ts = dsp.TimeScope('SampleRate', audio_fs, 'BufferLength', sim_time*audio_fs,...
 'TimeSpan', sim_time+50e-3);

% Use following objects to implement the fm discriminator
% dsp.IIRFilter for the digital integrator
% dsp.Delay for the delay

% Use the function pol2cart for getting Real/Imag components from
% Angle,Magnitude
% Use the function conj to compute the conjugate

% Use the function angle to get the angle of a complex data stream

release(obj_plutotx); release(obj_plutorx);
release(obj_spectrumdemod); release(obj_ts); release(obj_spectrummod);
