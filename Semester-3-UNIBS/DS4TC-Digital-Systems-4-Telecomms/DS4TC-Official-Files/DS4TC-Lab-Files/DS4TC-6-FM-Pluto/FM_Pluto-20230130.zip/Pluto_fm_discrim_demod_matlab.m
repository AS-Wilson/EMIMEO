% pluto-SDR(rx) FM Mono Non Coherent Discriminator Demodulator MATLAB Script
% - This script can be used to non-coherently demodulate an FM signal. 
% - NOTE: to end simulation early, use |Ctrl| + |C|

close('all'); clear('all');

%% PARAMETERS
plutosdr_fc        = 868e6;                     % SDR centre frequency in Hz
plutosdr_gain      = 30;                        % SDR gain in dB
plutosdr_fs        = 240e3;                     % SDR sampling rate
plutosdr_frmlen    = 12e3*5;                    % output data frame size (multiple of 5)
plutosdr_datatype  = 'single';                  % output data type
audio_fs         = 48e3;                        % audio output sampling rate
sim_time         = 2;                           % simulation time in seconds
sensitivity		 = 5;


plutosdr_frmtime = plutosdr_frmlen/plutosdr_fs; % calculate time for 1 frame of data


%% SYSTEM OBJECTS


% Set up modulated waveform
scale=5;

sw1 = dsp.SineWave;
sw1.Amplitude = 1/scale;
sw1.Frequency = 3e3;
sw1.ComplexOutput = false;
sw1.SampleRate = audio_fs;
sw1.SamplesPerFrame = plutosdr_frmlen/5; % to meet waveform size requirements

sw2 = dsp.SineWave;
sw2.Amplitude = 1/scale;
sw2.Frequency = 1e3;
sw2.ComplexOutput = false;
sw2.SampleRate = audio_fs;
sw2.SamplesPerFrame = plutosdr_frmlen/5; % to meet waveform size requirements

sine = sw1()+sw2();

% Digital Integrator
Digital_Int = dsp.IIRFilter('Numerator', 1, 'Denominator', [1 -1]);

% link to a physical pluto-sdr
obj_plutorx = sdrrx(...
    'Pluto',...
    'CenterFrequency', plutosdr_fc,...
    'GainSource', 'Manual',...
    'Gain', plutosdr_gain,...
    'BasebandSampleRate', plutosdr_fs, ...
    'SamplesPerFrame', plutosdr_frmlen,...
    'OutputDataType', plutosdr_datatype);

obj_plutotx = sdrtx(...
    'Pluto',...
    'CenterFrequency', plutosdr_fc,...
    'BasebandSampleRate', plutosdr_fs,...
    'Gain',-20);

% Rate conversion 48kHz -> 240kHz
obj_interp = dsp.FIRInterpolator('InterpolationFactor', 5,...
'Numerator', firpm(100, [0 15e3 20e3 (240e3/2)]/(240e3/2), [1 1 0 0], [1 1], 20) );  

% fir decimator - fs = 240kHz downto 48kHz
obj_decmtr = dsp.FIRDecimator(...
    'DecimationFactor', 5,...
    'Numerator', firpm(100,[0,15e3,20e3,(240e3/2)]/(240e3/2),...
    [1 1 0 0], [1 1], 20));


% delay
% dsp.Delay returns a System object, Delay, to delay the input by
% a specified number of samples (or frames).
obj_delay = dsp.Delay(1);

% spectrum analyzers
obj_spectrummod   = dsp.SpectrumAnalyzer(...
    'Name', 'Spectrum Analyzer Modulated',...
    'Title', 'Spectrum Analyzer Modulated',...
    'SpectrumType', 'Power density',...
    'FrequencySpan', 'Full',...
    'SampleRate', plutosdr_fs);
obj_spectrumdemod = dsp.SpectrumAnalyzer(...
    'Name', 'Spectrum Analyzer Demodulated',...
    'Title', 'Spectrum Analyzer Demodulated',...
    'SpectrumType', 'Power density',...
    'FrequencySpan', 'Full',...
    'SampleRate', audio_fs);

% time display object
obj_ts = dsp.TimeScope('SampleRate', audio_fs, 'BufferLength', sim_time*audio_fs,...
 'TimeSpan', sim_time+50e-3);


%% SIMULATION
% FM: the frequency (Int of phase) of the QAM is dictated by the signal
tx_magnitude = 1;
tx_angle = sensitivity*Digital_Int(sine());
[tx_real, tx_imag] = pol2cart(tx_angle,tx_magnitude);
tx_wave = complex(tx_real, tx_imag);
% Resample tx_wave
tx_wave_resampled = obj_interp(tx_wave./max(tx_wave));


% reset run_time to 0 (secs)
run_time = 0;

% TX
transmitRepeat(obj_plutotx, tx_wave_resampled);	%continously transmit

% loop while run_time is less than sim_time
while run_time < sim_time
    
    run_time
 
	% fetch a frame from obj_plutosdr (live or offline)
    plutosdr_data = obj_plutorx();
    
    % update 'modulated' spectrum analyzer window with new data
    obj_spectrummod(plutosdr_data);
    
    % implement frequency discriminator
    discrim_delay = obj_delay(plutosdr_data);
    discrim_conj  = conj(plutosdr_data);
    discrim_pd    = discrim_delay.*discrim_conj;
    discrim_arg   = angle(discrim_pd);
    
    % decimate + de-emphasis filter data
    data_dec = obj_decmtr(discrim_arg);
    
    % update 'demodulated' spectrum analyzer window with new data
    obj_spectrumdemod(data_dec);
    % plot demod data in time domain
    obj_ts(data_dec);

    % update run_time after processing another frame
    run_time = run_time + plutosdr_frmtime;
    
end

release(obj_plutotx); release(obj_plutorx);
release(obj_spectrumdemod); release(obj_ts); release(obj_spectrummod);
