%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%% Author   : David Marcus, PE
%%% Date     : 03 NOV 2019
%%% Rev      : 1 - Initial Release
%
%%%%%%%%%%%%%%% BPSK Project, No Hardware Required %%%%%%%%%%%%%%%
%
%%% Run script to create BPSK modulated message, model transmission of
%%% message through AWGN channel with phase and frequency offsets, receive
%%% and filter data, perform receiver compensation, decode message
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

message_num = 1; % Set to 1, 2, or 3
sample_rate = 300e3;
data_rate = 20e3;

[IQmessage,message_length] = createMessage(message_num);

sps = sample_rate/data_rate;

txFilter = comm.RaisedCosineTransmitFilter( ...
    'OutputSamplesPerSymbol',sps,'FilterSpanInSymbols',2);

tx_signal = txFilter([IQmessage;IQmessage;IQmessage;IQmessage;IQmessage]);

rxFilter = comm.RaisedCosineReceiveFilter(...
    'InputSamplesPerSymbol',sps,'DecimationFactor',sps,...
    'FilterSpanInSymbols',2);

pfo = comm.PhaseFrequencyOffset('PhaseOffset',45,'FrequencyOffset',... % Increase frequency offset and phase offset to degrade signal
    1000,'SampleRate',sample_rate);

channel = comm.AWGNChannel('SamplesPerSymbol',sps,'EbNo',30); % Decrease EbNo to degrade signal

rx_signal = rxFilter(channel(pfo(tx_signal)));

figure(1)
plot(10*log10(abs(channel(pfo(tx_signal)))));
title('Power Spectrum Plot Rx Signal');

[decodedMessage,rx_coarse,rx_fine,data_start_index] = ...
    decodeMessage(rx_signal,message_length,sample_rate);

scatterplot(rx_coarse(data_start_index:data_start_index+message_length*8-1))
title('Coarse Synchronization Scatterplot')

scatterplot(rx_fine(data_start_index:data_start_index+message_length*8-1))
title('Coarse Synchronization Scatterplot')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%